^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package ur20_moveit_config
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.3.2 (2023-12-18)
------------------
* UR20 description and meshes (`#657 <https://github.com/ros-industrial/universal_robot/issues/657>`_)
* Contributors: Rune Søe-Knudsen
