# ur_kinematics
IKFast plugin to use as an IK solver with MoveIt!

**NOTE**: This does not use the calibrated robot information but the hardcoded uncalibrated robot
model which is why it is not suggested to use this.
