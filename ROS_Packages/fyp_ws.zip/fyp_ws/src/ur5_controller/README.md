1. Packages required:
	Universal_robot:
	```
	~/catkin_ws/src$ git clone -b <distro>-devel https://github.com/ros-industrial/universal_robot.git
	$ rosdep update
	$ rosdep install --rosdistro $ROS_DISTRO --ignore-src --from-paths src
	```
	
2. Install urdf-tutorial
	```
	sudo apt-get install ros-<distro>-urdf-tutorial
	```
	Replace <distro> with the ros version
	
3. Build the workspace
	
